#include <iostream>
using namespace std;

int main() {
    cout << "Hello" << endl;
    return 0;
    cout << "Hi" <<endl;
}